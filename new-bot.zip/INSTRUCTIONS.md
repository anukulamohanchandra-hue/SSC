# AgentDesk — Setup & Run Guide (Windows)

A dockerized multi-agent trading application. Four language models — **Claude,
ChatGPT, Gemini, and Grok** — independently decide trades, and the app executes
them on **Angel One** via SmartAPI. Your wallet is split **evenly** across every
engine you enable. The dashboard shows **live profit/loss**.

---

## ⚠️ READ THIS FIRST — RISK WARNING

- This software lets language models place **real orders with real money and no
  human approval**. LLMs are not financial advisors and **routinely lose money**.
- It ships in **Paper trading** mode (simulated fills) by default. **Keep it
  there** until you fully understand the behaviour.
- Switching to **Live** is a deliberate, separate action that asks you to confirm.
- This is **not financial advice**. You alone are responsible for every trade,
  every loss, and for complying with your local laws and your broker's terms.
- Algorithmic / automated trading may require explicit broker approval. Confirm
  with Angel One that automated order placement is permitted on your account.

---

## 1. Prerequisites (MANDATORY)

1. **Windows 10/11** with **Docker Desktop** installed and running.
   Download: https://www.docker.com/products/docker-desktop/
   After installing, launch Docker Desktop and wait until it says *"Engine
   running"* in the bottom-left.
2. A working **internet connection** (the container must reach Angel One and the
   LLM APIs).
3. An **Angel One** account with **SmartAPI** enabled (see Section 4).
4. At least **one** LLM API key (Claude / ChatGPT / Gemini / Grok). You can run
   with just one engine; you do **not** need all four.

> You do **not** need to install Python. Everything runs inside Docker.

---

## 2. Run the app (Windows CMD)

Open **Command Prompt** (press `Win`, type `cmd`, hit Enter) and run the
commands below **in order**.

**Step 1 — go to the project folder** (adjust the path to where you unzipped it):

```cmd
cd C:\Users\YourName\Downloads\angel-multiagent-trader
```

**Step 2 — build and start the container:**

```cmd
docker compose up --build
```

Leave this window open — it streams the app's logs. The first build downloads
dependencies and may take a few minutes.

**Step 3 — open the interface** in your browser:

```
http://localhost:8000
```

That's it. Configure everything in the web UI (Section 3).

### Stopping

Press `Ctrl + C` in the CMD window, then:

```cmd
docker compose down
```

### Running again later

```cmd
cd C:\Users\YourName\Downloads\angel-multiagent-trader
docker compose up
```

(Use `--build` again only after you change the code.)

> **No Compose?** If `docker compose` is unavailable, use the classic commands:
> ```cmd
> docker build -t agentdesk .
> docker run -p 8000:8000 agentdesk
> ```

---

## 3. Using the interface

All keys are entered here and held **in memory only** — never written to disk or
to environment variables. They are lost when the container stops, by design.

1. **① Angel One** — enter your API key, client code, MPIN, and TOTP secret
   (Section 4 explains each).
2. **② Decision engines** — for each LLM you want to use: leave its toggle **on**,
   paste its API key, and (optionally) edit the model name. Engines with the
   toggle on **and** a key filled in will trade; the rest stay idle. The wallet is
   divided evenly across the active engines.
3. **③ Capital & risk**
   - **Wallet amount (₹)** — total capital to deploy across all engines.
   - **Risk % of capital / trade** — the maximum percentage of an engine's
     *allocated* capital it may lose on a single trade if the stop-loss is hit.
     This drives position sizing.
   - **Default stop-loss %**, **Max positions / engine**, and **Decision interval**
     (how often, in seconds, the engines re-evaluate the market).
4. **④ Segment & mode**
   - **Trade segment**: *Intraday (cash)* or *F&O (NFO)* — see Section 6.
   - **Execution**: keep **Paper trading** ON to start. Turning it off enables
     **Live** trading and asks you to confirm.
   - **Ignore market hours**: lets paper runs work any time of day.
   - **Auto square-off**: flattens intraday positions near 15:15 IST.
   - **Watchlist**: the symbols the engines may trade.
5. Click **Save configuration**, then **▶ Start engine** (top right).
6. Watch the dashboard: total live P&L, per-engine cards (with each model's last
   action and market view), open positions, and the activity log.
7. **Flatten all positions** closes everything immediately. **■ Stop** halts the
   engines.

---

## 4. Getting your Angel One SmartAPI credentials

1. Log in to the **Angel One SmartAPI** developer portal:
   https://smartapi.angelbroking.com/
2. **Create an app** (choose the *Trading / Market* API). It gives you an
   **API key** — paste this into the *API key* field.
3. **Client code** — your Angel One login ID (for example `A123456`).
4. **MPIN / PIN** — the PIN you use to log in to Angel One.
5. **TOTP secret** — when you enable two-factor authentication, Angel One shows a
   QR code with a **manual entry key** (a base32 string). That string is the TOTP
   secret. The app uses it to generate the 6-digit 2FA code automatically on each
   login, so you don't have to type a fresh code every time.

> Keep these private. Anyone with them can trade on your account.

---

## 5. Getting LLM API keys

You only need keys for the engines you switch on.

- **Claude (Anthropic):** https://console.anthropic.com/ → *API Keys*
- **ChatGPT (OpenAI):** https://platform.openai.com/api-keys
- **Gemini (Google):** https://aistudio.google.com/app/apikey
- **Grok (xAI):** https://console.x.ai/

Each provider bills you directly for usage. The engines call these APIs every
decision interval, so usage costs grow with shorter intervals and more engines.

### Updating model names (important)

Model names change often. Each engine row has an editable **model** field
pre-filled with a sensible default. If a provider releases a newer model or
retires an old one, just type the current model identifier into that field — no
code changes or rebuild needed. If an engine errors with something like *"model
not found"*, an outdated model name is the usual cause.

---

## 6. Intraday vs F&O symbols

- **Intraday (cash):** use cash-segment symbols ending in `-EQ`, e.g.
  `SBIN-EQ`, `RELIANCE-EQ`, `INFY-EQ`. Orders route to NSE as intraday (MIS).
- **F&O (NFO):** use the **exact** NFO trading symbol for the contract, e.g.
  `BANKNIFTY24DEC51000CE` or a futures symbol like `NIFTY24DECFUT`. These change
  every expiry, so update the watchlist accordingly. Wrong or expired symbols
  will be skipped with an error in the log.

Derivatives are leveraged and can lose money far faster than cash. Treat F&O with
extra caution and paper-test heavily.

---

## 7. Paper-test first, then go live

1. Start in **Paper** mode with **Ignore market hours** ON. Simulated prices let
   you watch the engines make decisions any time, with no real money and no
   broker connection required.
2. Confirm the engines behave sensibly: positions open and close, P&L updates,
   stop-losses and square-off work, the activity log makes sense.
3. Only when you are confident: enter **valid Angel One credentials**, turn
   **Paper trading OFF** (confirm the live warning), and start during market
   hours. Begin with a **small wallet** and a **low risk %**.

---

## 8. Troubleshooting

- **Browser shows nothing / can't connect** — confirm the CMD window says
  Uvicorn is *"Application startup complete"*, Docker Desktop is running, and you
  opened `http://localhost:8000` (not https).
- **Port already in use** — change the host port: edit `docker-compose.yml` and
  set the mapping to e.g. `"8080:8000"`, then open `http://localhost:8080`.
- **Angel login fails** — recheck client code, MPIN, and especially the TOTP
  secret (it must be the base32 text behind the QR code, no spaces).
- **An engine shows an error** — usually a wrong/expired model name or an invalid
  LLM key; fix it in that engine's row and Save again.
- **"Could not load instrument master"** — the container has no internet. Paper
  mode still works with simulated tokens; live trading needs connectivity.
- **Reset everything** — `Ctrl + C`, then `docker compose down`, then
  `docker compose up` again. Because keys live only in memory, you'll re-enter
  them after a restart (this is intentional).

---

*AgentDesk is provided as-is, for educational and experimental use. No warranty.
Trading involves substantial risk of loss. Not financial advice.*
