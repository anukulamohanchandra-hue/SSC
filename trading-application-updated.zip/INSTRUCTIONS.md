# AgentDesk — Setup & Run Guide (Windows)

A dockerized multi-agent trading application. Four language models — **Claude,
ChatGPT, Gemini, and Grok** — independently decide trades, and the app executes
them on **Angel One** via SmartAPI. Your wallet is split **evenly** across every
engine you enable. The dashboard shows **live profit/loss**.

---

## ⚠️ READ THIS FIRST — RISK WARNING

- This software lets language models place **real orders with real money and no
  human approval**. LLMs are not financial advisors and **routinely lose money**.
- It ships in **Paper trading** mode (simulated fills) by default. **Keep it
  there** until you fully understand the behaviour.
- Switching to **Live** is a deliberate, separate action that asks you to confirm.
- This is **not financial advice**. You alone are responsible for every trade,
  every loss, and for complying with your local laws and your broker's terms.
- Algorithmic / automated trading may require explicit broker approval. Confirm
  with Angel One that automated order placement is permitted on your account.

---

## 1. Prerequisites (MANDATORY)

1. **Windows 10/11** with **Docker Desktop** installed and running.
   Download: https://www.docker.com/products/docker-desktop/
   After installing, launch Docker Desktop and wait until it says *"Engine
   running"* in the bottom-left.
2. A working **internet connection** (the container must reach Angel One and the
   LLM APIs).
3. An **Angel One** account with **SmartAPI** enabled (see Section 4).
4. At least **one** LLM API key (Claude / ChatGPT / Gemini / Grok). You can run
   with just one engine; you do **not** need all four.

> You do **not** need to install Python. Everything runs inside Docker.

---

## 2. Run the app (Windows CMD)

Open **Command Prompt** (press `Win`, type `cmd`, hit Enter) and run the
commands below **in order**.

**Step 1 — go to the project folder** (adjust the path to where you unzipped it):

```cmd
cd C:\Users\YourName\Downloads\angel-multiagent-trader
```

**Step 2 — build and start the container:**

```cmd
docker compose up --build
```

Leave this window open — it streams the app's logs. The first build downloads
dependencies and may take a few minutes.

**Step 3 — open the interface** in your browser:

```
http://localhost:8000
```

That's it. Configure everything in the web UI (Section 3).

### Stopping

Press `Ctrl + C` in the CMD window, then:

```cmd
docker compose down
```

### Running again later

```cmd
cd C:\Users\YourName\Downloads\angel-multiagent-trader
docker compose up
```

(Use `--build` again only after you change the code.)

> **No Compose?** If `docker compose` is unavailable, use the classic commands:
> ```cmd
> docker build -t agentdesk .
> docker run -p 8000:8000 agentdesk
> ```

---

## 3. Using the interface

All keys are entered here and held **in memory only** — never written to disk or
to environment variables. They are lost when the container stops, by design.

1. **① Angel One** — enter your API key, client code, MPIN, and TOTP secret
   (Section 4 explains each).
2. **② Decision engines** — for each LLM you want to use: leave its toggle **on**,
   paste its API key, and (optionally) edit the model name. Engines with the
   toggle on **and** a key filled in will trade; the rest stay idle. The wallet is
   divided evenly across the active engines.
3. **③ Capital & risk**
   - **Wallet amount (₹)** — total capital to deploy across all engines.
   - **Risk % of capital / trade** — the maximum percentage of an engine's
     *allocated* capital it may lose on a single trade if the stop-loss is hit.
     This drives position sizing.
   - **Default stop-loss %**, **Max positions / engine**, **Decision interval**
     (how often, in seconds, the engines re-evaluate the market), and
     **Min move % to re-query** (a cost saver — see Section 9).
4. **④ Segment & mode**
   - **Trade segment**: *Intraday (cash)* or *F&O (NFO)* — see Section 6.
   - **Execution**: keep **Paper trading** ON to start. Turning it off enables
     **Live** trading and asks you to confirm.
   - **Ignore market hours**: lets paper runs work any time of day.
   - **Auto square-off**: flattens intraday positions near 15:15 IST.
   - **Auto stop-loss / target**: the engine closes a position the instant its
     stop-loss or target is reached, without waiting for the next LLM round
     (recommended ON — see Section 10).
   - **Skip unchanged cycles**: saves money by not calling the LLMs when prices
     have barely moved and nothing is open (see Section 9).
   - **Watchlist**: the symbols the engines may trade. **Load from file** /
     **Save to file** sync it with `watchlist.txt` (see Section 6).
5. Click **Save configuration**, then **▶ Start engine** (top right).
6. Watch the dashboard:
   - **Net P&L** headline = **Booked** (realised, from closed trades) + **Open**
     (live, from positions still running). All three are shown together.
   - Per-engine cards (each model's last action and market view), **Open
     positions**, **Closed trades** (full history with entry/exit/P&L/reason and a
     win/loss summary), and the activity log.
7. **Flatten all positions** closes everything immediately. **■ Stop** halts the
   engines. The closed-trades history stays visible after you stop; starting a new
   run begins a fresh session and clears it.

---

## 4. Getting your Angel One SmartAPI credentials

1. Log in to the **Angel One SmartAPI** developer portal:
   https://smartapi.angelbroking.com/
2. **Create an app** (choose the *Trading / Market* API). It gives you an
   **API key** — paste this into the *API key* field.
3. **Client code** — your Angel One login ID (for example `A123456`).
4. **MPIN / PIN** — the PIN you use to log in to Angel One.
5. **TOTP secret** — when you enable two-factor authentication, Angel One shows a
   QR code with a **manual entry key** (a base32 string). That string is the TOTP
   secret. The app uses it to generate the 6-digit 2FA code automatically on each
   login, so you don't have to type a fresh code every time.

> Keep these private. Anyone with them can trade on your account.

---

## 5. Getting LLM API keys

You only need keys for the engines you switch on.

- **Claude (Anthropic):** https://console.anthropic.com/ → *API Keys*
- **ChatGPT (OpenAI):** https://platform.openai.com/api-keys
- **Gemini (Google):** https://aistudio.google.com/app/apikey
- **Grok (xAI):** https://console.x.ai/

Each provider bills you directly for usage. The engines call these APIs every
decision interval, so usage costs grow with shorter intervals and more engines.

### Default models & updating them (important)

Model names change often, so each engine row has an editable **model** field. The
defaults are chosen to be **inexpensive** (see Section 9):

| Engine | Default model | Notes |
| --- | --- | --- |
| Claude | `claude-haiku-4-5` | Anthropic's cheapest current tier |
| ChatGPT | `gpt-4o-mini` | `gpt-4.1-nano` is even cheaper |
| Gemini | `gemini-2.5-flash-lite` | the old `gemini-2.0-flash` was retired June 2026 |
| Grok | `grok-4.3` | `grok-4.1-fast` is cheaper if your account has it |

If a provider releases a newer model or retires one, just type the current model
identifier into that field — no code changes or rebuild needed. If an engine
errors with *"model not found"* (or similar), an outdated model name is the usual
cause; update it and Save again.

---

## 6. Intraday vs F&O symbols

- **Intraday (cash):** use cash-segment symbols ending in `-EQ`, e.g.
  `SBIN-EQ`, `RELIANCE-EQ`, `INFY-EQ`. Orders route to NSE as intraday (MIS).
- **F&O (NFO):** use the **exact** NFO trading symbol for the contract, e.g.
  `BANKNIFTY24DEC51000CE` or a futures symbol like `NIFTY24DECFUT`. These change
  every expiry, so update the watchlist accordingly. Wrong or expired symbols
  will be skipped with an error in the log.

Derivatives are leveraged and can lose money far faster than cash. Treat F&O with
extra caution and paper-test heavily.

### Editing the watchlist file

The watchlist lives in **`watchlist.txt`** in the project folder — one symbol per
line (commas also work; lines starting with `#` are ignored). You can manage it
two ways, and they stay in sync:

- **On disk:** open `watchlist.txt` in any text editor, change the symbols, save.
  Because the file is mounted into the container, the change is picked up on the
  next **Start** — no rebuild needed.
- **In the UI:** the watchlist box has **⟳ Load from file** (pull the file's
  symbols into the box) and **⤓ Save to file** (write the box's symbols back to
  `watchlist.txt`). The box is auto-loaded from the file when the page opens.

When you click **Save configuration**, whatever is in the box is what the engines
will trade for that run.

---

## 7. Paper-test first, then go live

1. Start in **Paper** mode with **Ignore market hours** ON. Simulated prices let
   you watch the engines make decisions any time, with no real money and no
   broker connection required.
2. Confirm the engines behave sensibly: positions open and close, P&L updates,
   stop-losses and square-off work, the activity log makes sense.
3. Only when you are confident: enter **valid Angel One credentials**, turn
   **Paper trading OFF** (confirm the live warning), and start during market
   hours. Begin with a **small wallet** and a **low risk %**.

---

## 8. Troubleshooting

- **Browser shows nothing / can't connect** — confirm the CMD window says
  Uvicorn is *"Application startup complete"*, Docker Desktop is running, and you
  opened `http://localhost:8000` (not https).
- **Port already in use** — change the host port: edit `docker-compose.yml` and
  set the mapping to e.g. `"8080:8000"`, then open `http://localhost:8080`.
- **Angel login fails** — recheck client code, MPIN, and especially the TOTP
  secret (it must be the base32 text behind the QR code, no spaces).
- **An engine shows an error** — usually a wrong/expired model name or an invalid
  LLM key; fix it in that engine's row and Save again.
- **"Could not load instrument master"** — the container has no internet. Paper
  mode still works with simulated tokens; live trading needs connectivity.
- **Reset everything** — `Ctrl + C`, then `docker compose down`, then
  `docker compose up` again. Because keys live only in memory, you'll re-enter
  them after a restart (this is intentional).

---

## 9. Making the LLM calls cheaper

The cost of a run is roughly *(number of enabled engines) × (calls per hour) ×
(tokens per call)*. This version pulls every one of those levers:

- **Cheap models by default.** Each engine ships pointing at its provider's
  low-cost tier (Section 5). For the absolute floor you can switch ChatGPT to
  `gpt-4.1-nano` and Gemini stays on `gemini-2.5-flash-lite` — both around
  $0.10–$0.15 per million input tokens.
- **Output is capped.** Each decision is limited to a small token budget and the
  prompt asks for terse JSON, so you never pay for long essays.
- **Compact prompts.** Instead of dumping raw price lists, the app sends a short
  line of pre-computed indicators per symbol (price, % change, two moving
  averages, RSI, volatility). Fewer input tokens *and* better signal.
- **Skip unchanged cycles (toggle, default ON).** When prices have moved less
  than your **Min move %** since the last round *and* nothing is open, the engine
  skips the LLM calls entirely that cycle and logs that it did. In a quiet market
  this alone can cut calls dramatically.
- **Lengthen the decision interval.** Going from 60s to 180–300s cuts calls 3–5×.
  Intraday signals rarely need sub-minute re-evaluation.
- **Run fewer engines.** Each enabled engine is a full, independent cost stream.
  One or two good models often beats four.

Extra levers your provider offers (outside this app): most have a **Batch API**
(~50% off) and **prompt caching** (up to ~90% off repeated input) — useful if you
later adapt the code. Also set **spend limits** in each provider's console so a
runaway loop can't surprise you.

---

## 10. Helping the engines trade better

A single price point is a weak basis for a decision, so this version gives the
models more structure and adds mechanical discipline around them:

- **Technical context in every prompt.** Each symbol arrives with a 5- vs
  20-period moving average (trend), recent range, RSI, and realised volatility,
  plus brief guidance (trade with the trend, avoid buying when RSI > 75 or
  shorting when RSI < 25, widen stops when volatility is high, be selective).
- **Automatic stop-loss / target (toggle, default ON).** The engine watches open
  positions on every price tick and closes one the instant its stop-loss or
  profit target is hit — it does **not** wait for the next LLM round. This is the
  single biggest risk-discipline improvement; keep it on.
- **Anti-churn cooldown.** An engine can't immediately flip a position it just
  opened, which prevents expensive thrash where a model reverses itself every
  cycle. (The automatic stop-loss still protects you during the cooldown.)
- **Position sizing is automatic.** The model only chooses direction and
  stop/target; size is derived from your **Risk %** and the stop distance, so no
  single trade can lose more than you allow.

Practical tips: paper-test each model on the same watchlist to see which behaves
best for your style, start with **2–4 liquid symbols** rather than a long list,
and use a **realistic stop-loss** (tight stops get hit by noise; very wide stops
defeat the risk limit). Remember that LLMs have **no special predictive power**
over markets — these features improve discipline and consistency, not certainty.

---

*AgentDesk is provided as-is, for educational and experimental use. No warranty.
Trading involves substantial risk of loss. Not financial advice.*
