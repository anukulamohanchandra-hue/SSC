# ============================================================
# FILE: signals/base.py
# THE SIGNAL ENGINE IS DELIBERATELY NOT IMPLEMENTED.
#
# This is the boundary the whole system is built around:
#   - The infrastructure (risk sizing, validation, rate limiting,
#     compliance, audit, execution safety) is provided and is sound.
#   - The *edge* — deciding when to BUY/SELL and why — is yours.
#     It must be backtested and forward paper-traded before you ever
#     set TRADING_MODE=LIVE. No validator in this codebase can tell a
#     profitable signal from a coin flip; only out-of-sample testing can.
#
# Implement generate_intent() in a subclass. Until you do, the system
# runs with NullSignalEngine, which always HOLDs and places nothing.
# ============================================================
import abc
from typing import Optional

from risk.risk_manifest import RiskManifest, RiskGovernor


class SignalEngine(abc.ABC):
    """Maps a market signal_state to an OrderIntent (or None to HOLD)."""

    @abc.abstractmethod
    async def generate_intent(self, signal_state: dict,
                              manifest: RiskManifest) -> Optional[dict]:
        """
        Return a canonical OrderIntent dict, or None to take no action.
        Any intent you return is still subject to validation and the
        manifest's sizing caps downstream — you cannot size past the
        risk governor from here.
        """
        raise NotImplementedError


class NullSignalEngine(SignalEngine):
    """Safe default. Never trades. The system is inert until you replace it."""

    async def generate_intent(self, signal_state: dict,
                              manifest: RiskManifest) -> Optional[dict]:
        return None


def build_intent_skeleton(symbol: str, token: str, exchange: str,
                          action: str, quantity: int,
                          stop_loss: float, target: float,
                          manifest: RiskManifest,
                          entry_price: float) -> dict:
    """
    Helper for your SignalEngine implementation: assembles a schema-shaped
    OrderIntent stamped with the authorising manifest. You still choose
    action/levels; this only wires the plumbing fields correctly.
    """
    rr = abs(target - entry_price) / abs(entry_price - stop_loss) \
        if entry_price != stop_loss else 0.0
    pos_inr = quantity * entry_price
    return {
        "schema_version": "2.1",
        "instrument": {"symbol": symbol, "token": token,
                       "exchange": exchange, "segment": "EQUITY"},
        "signal": {"action": action, "order_type": "MARKET",
                   "product_type": "INTRADAY", "quantity": int(quantity),
                   "limit_price": None, "trigger_price": None, "validity": "DAY"},
        "risk_params": {"stop_loss_price": stop_loss, "target_price": target,
                        "risk_reward_ratio": round(rr, 2),
                        "max_slippage_tolerance_pct": 0.15},
        "routing_meta": {"primary_model": "USER_STRATEGY", "fallback_used": False,
                         "news_sentiment_composite": 0.0, "regime": "CHOPPY"},
        "compliance": {"kelly_fraction_used": manifest.kelly_fraction,
                       "position_size_inr": round(pos_inr, 2),
                       "pct_of_nav": round(pos_inr / manifest.nav, 4)
                       if manifest.nav else 0.0,
                       "risk_manifest_version": manifest.manifest_id},
    }
