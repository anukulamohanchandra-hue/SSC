# ============================================================
# FILE: config.py
# Central configuration. Read once at startup.
#
# The single most important line in this file is TRADING_MODE.
# It defaults to PAPER. Nothing routes a real order to Angel One
# unless TRADING_MODE == LIVE *and* LIVE_TRADING_CONFIRMED is True.
# ============================================================
import os
from dataclasses import dataclass, field
from enum import Enum


class TradingMode(str, Enum):
    PAPER = "PAPER"   # Simulated fills. No broker order is ever placed. (DEFAULT)
    LIVE = "LIVE"     # Real orders hit Angel One. Requires explicit confirmation.


def _env_bool(key: str, default: bool = False) -> bool:
    return os.getenv(key, str(default)).strip().lower() in ("1", "true", "yes", "on")


@dataclass(frozen=True)
class Config:
    # ---- Mode (safety-critical) -------------------------------------------
    # Default PAPER. To go live you must set BOTH env vars, deliberately:
    #   TRADING_MODE=LIVE  and  LIVE_TRADING_CONFIRMED=true
    trading_mode: TradingMode = field(
        default_factory=lambda: TradingMode(os.getenv("TRADING_MODE", "PAPER").upper())
    )
    live_trading_confirmed: bool = field(
        default_factory=lambda: _env_bool("LIVE_TRADING_CONFIRMED", False)
    )

    # ---- Angel One credentials (from environment, never hard-coded) -------
    api_key: str = field(default_factory=lambda: os.getenv("ANGEL_API_KEY", ""))
    client_id: str = field(default_factory=lambda: os.getenv("ANGEL_CLIENT_ID", ""))
    password: str = field(default_factory=lambda: os.getenv("ANGEL_PASSWORD", ""))
    totp_secret: str = field(default_factory=lambda: os.getenv("ANGEL_TOTP_SECRET", ""))

    # ---- SEBI / Angel One compliance --------------------------------------
    # The static IP you registered in SmartApi -> My Profile -> My APIs.
    # Only orders egressing from this IP are accepted by Angel One.
    registered_static_ip: str = field(
        default_factory=lambda: os.getenv("REGISTERED_STATIC_IP", "")
    )
    # Hard cap. Angel One enforces 10 OPS across place/modify/cancel/GTT.
    # We stay a hair under to avoid edge-of-limit rejections.
    max_orders_per_second: float = 9.0
    enforce_static_ip_check: bool = field(
        default_factory=lambda: _env_bool("ENFORCE_STATIC_IP_CHECK", False)
    )

    # ---- Risk governance (Role 1) -----------------------------------------
    kelly_fraction_cap: float = 0.25          # hard ceiling on f*
    kelly_base_multiplier: float = 0.50       # half-Kelly base
    max_pct_nav_per_instrument: float = 0.05  # never > 5% NAV in one name
    atr_multiplier_default: float = 2.0
    atr_multiplier_high_vix: float = 3.0
    high_vix_threshold: float = 20.0
    min_risk_reward_ratio: float = 1.5

    drawdown_soft_pct: float = -0.01   # halve sizing + alert
    drawdown_hard_pct: float = -0.02   # flatten + halt
    consecutive_api_failures_halt: int = 3

    # ---- Market calendar / hours (IST) ------------------------------------
    market_open: str = "09:15"
    market_close: str = "15:30"
    preopen_start: str = "09:00"
    preopen_end: str = "09:08"

    # ---- Infra ------------------------------------------------------------
    redis_url: str = field(
        default_factory=lambda: os.getenv("REDIS_URL", "redis://localhost:6379")
    )
    audit_stream: str = "trade_audit_log"

    def assert_live_allowed(self) -> None:
        """Raise unless live trading has been deliberately enabled."""
        if self.trading_mode is TradingMode.LIVE and not self.live_trading_confirmed:
            raise RuntimeError(
                "TRADING_MODE=LIVE but LIVE_TRADING_CONFIRMED is not set. "
                "Refusing to place real orders. Set LIVE_TRADING_CONFIRMED=true "
                "only after you have paper-traded and backtested your signal engine."
            )


CONFIG = Config()
