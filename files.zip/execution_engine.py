# ============================================================
# FILE: broker/execution_engine.py
# The execution spine. Every order — paper or live — passes through here.
#
# Guarantees enforced on EVERY order:
#   1. Mode gate     — PAPER simulates; LIVE requires explicit confirmation.
#   2. Halt gate     — circuit breaker latched => no orders.
#   3. Rate gate     — token bucket keeps us under the 10 OPS ceiling.
#   4. Validation    — structural guardrail must pass.
#   5. Static IP gate (LIVE only) — egress IP must match the registered IP.
#   6. Audit         — written before the receipt is returned.
# ============================================================
import asyncio
import json
import logging
import time
from datetime import datetime, timezone
from typing import Optional

import redis.asyncio as aioredis

from config import Config, TradingMode
from broker.circuit_breaker import (CircuitBreaker, OrderExecutionError,
                                     SystemHaltException)
from broker.rate_limiter import AsyncTokenBucket
from broker.session_manager import AngelOneSession
from risk.risk_manifest import RiskManifest
from risk.order_validator import validate_order_intent

logger = logging.getLogger("broker.execution")

MAX_ORDER_RETRIES = 3
RETRY_BASE_DELAY_S = 0.5


class ExecutionEngine:
    def __init__(self, cfg: Config, session: AngelOneSession,
                 circuit_breaker: CircuitBreaker, redis_client=None):
        self.cfg = cfg
        self.session = session
        self.cb = circuit_breaker
        self._redis = redis_client
        self._limiter = AsyncTokenBucket(rate=cfg.max_orders_per_second)
        self._paper_seq = 0
        cfg.assert_live_allowed()  # fail fast at construction if misconfigured
        logger.info("[Execution] initialised in %s mode", cfg.trading_mode.value)

    # ---- public API -------------------------------------------------------
    async def place_order(self, intent: dict, manifest: RiskManifest) -> dict:
        if self.cb.is_halted:
            raise SystemHaltException("circuit breaker latched — placement blocked")

        ok, reason = validate_order_intent(intent, manifest)
        if not ok:
            await self._audit(intent, {"status": "REJECTED_VALIDATION", "reason": reason})
            logger.warning("[Execution] intent rejected: %s", reason)
            return {"status": "HOLD", "reason": reason}

        await self._limiter.acquire()  # enforce 10 OPS before anything else

        if self.cfg.trading_mode is TradingMode.PAPER:
            return await self._paper_fill(intent)
        return await self._live_place(intent)

    async def emergency_flatten_all(self) -> None:
        """SYSTEM_HALT_LEVEL_2. Throttled so the close-out never breaches OPS."""
        logger.critical("[Execution] EMERGENCY FLATTEN initiated")
        if self.cfg.trading_mode is TradingMode.PAPER:
            logger.critical("[Execution] (paper mode) would flatten all positions")
            return
        await self.session.ensure_valid()
        positions = await asyncio.to_thread(self.session.smart.position)
        for pos in (positions.get("data") or []):
            netqty = int(pos.get("netqty", 0))
            if netqty == 0:
                continue
            await self._limiter.acquire()
            params = {
                "variety": "NORMAL", "tradingsymbol": pos["tradingsymbol"],
                "symboltoken": pos["symboltoken"], "exchange": pos["exchange"],
                "transactiontype": "SELL" if netqty > 0 else "BUY",
                "ordertype": "MARKET", "producttype": pos["producttype"],
                "duration": "IOC", "price": "0", "triggerprice": "0",
                "quantity": str(abs(netqty)),
            }
            try:
                await asyncio.to_thread(self.session.smart.placeOrder, params)
            except Exception as e:
                logger.error("[Execution] flatten failed for %s: %s",
                             pos["tradingsymbol"], e)

    async def cancel_order(self, order_id: str, variety: str = "NORMAL") -> dict:
        if self.cfg.trading_mode is TradingMode.PAPER:
            return {"status": "PAPER_CANCELLED", "order_id": order_id}
        await self._limiter.acquire()
        await self.session.ensure_valid()
        return await asyncio.to_thread(self.session.smart.cancelOrder, variety, order_id)

    # ---- internals --------------------------------------------------------
    async def _paper_fill(self, intent: dict) -> dict:
        self._paper_seq += 1
        receipt = {
            "order_id": f"PAPER-{self._paper_seq}",
            "status": "PAPER_FILLED",
            "mode": "PAPER",
            "filled_at_ts": datetime.now(timezone.utc).isoformat(),
        }
        await self._audit(intent, receipt)
        return receipt

    async def _live_place(self, intent: dict) -> dict:
        self._assert_static_ip()
        await self.session.ensure_valid()

        params = {
            "variety": "NORMAL",
            "tradingsymbol": intent["instrument"]["symbol"],
            "symboltoken": intent["instrument"]["token"],
            "transactiontype": intent["signal"]["action"],
            "exchange": intent["instrument"]["exchange"],
            "ordertype": intent["signal"]["order_type"],
            "producttype": intent["signal"]["product_type"],
            "duration": intent["signal"]["validity"],
            "price": str(intent["signal"].get("limit_price") or "0"),
            "triggerprice": str(intent["signal"].get("trigger_price") or "0"),
            "quantity": str(intent["signal"]["quantity"]),
        }

        last_exc = None
        for attempt in range(MAX_ORDER_RETRIES):
            try:
                t0 = time.monotonic()
                resp = await asyncio.to_thread(self.session.smart.placeOrder, params)
                slippage_ms = round((time.monotonic() - t0) * 1000, 2)
                if resp and resp.get("status"):
                    self.cb.record_success()
                    receipt = {
                        "order_id": resp["data"]["orderid"],
                        "status": "PLACED",
                        "mode": "LIVE",
                        "model_slippage_ms": slippage_ms,
                        "placed_at_ts": datetime.now(timezone.utc).isoformat(),
                        "angel_one_response": resp,
                    }
                    await self._audit(intent, receipt)
                    return receipt
                raise ValueError(f"Angel One rejected order: {resp}")
            except Exception as e:
                last_exc = e
                delay = RETRY_BASE_DELAY_S * (2 ** attempt)
                logger.warning("[Execution] attempt %d failed: %s; retry in %ss",
                               attempt + 1, e, delay)
                await asyncio.sleep(delay)
                # Re-acquire a token for the retry so retries also respect OPS.
                await self._limiter.acquire()

        latched = self.cb.record_failure()
        await self._audit(intent, {"status": "FAILED", "error": str(last_exc)})
        if latched:
            raise SystemHaltException("circuit breaker threshold reached")
        raise OrderExecutionError(f"order failed after {MAX_ORDER_RETRIES} attempts: {last_exc}")

    def _assert_static_ip(self) -> None:
        """
        Live orders are only accepted by Angel One from your registered IP.
        We surface a clear local error rather than letting the broker reject.
        Requires the 'requests' package and outbound access to an IP-echo
        service; disabled by default (ENFORCE_STATIC_IP_CHECK).
        """
        if not self.cfg.enforce_static_ip_check:
            return
        if not self.cfg.registered_static_ip:
            raise RuntimeError("ENFORCE_STATIC_IP_CHECK set but REGISTERED_STATIC_IP empty")
        try:
            import requests
            current = requests.get("https://api.ipify.org", timeout=3).text.strip()
        except Exception as e:
            raise RuntimeError(f"could not determine egress IP: {e}")
        if current != self.cfg.registered_static_ip:
            raise RuntimeError(
                f"egress IP {current} != registered {self.cfg.registered_static_ip}; "
                "Angel One would reject this order")

    async def _audit(self, intent: dict, receipt: dict) -> None:
        entry = {
            "ts_utc": datetime.now(timezone.utc).isoformat(),
            "mode": self.cfg.trading_mode.value,
            "symbol": str(intent.get("instrument", {}).get("symbol", "")),
            "action": str(intent.get("signal", {}).get("action", "")),
            "quantity": str(intent.get("signal", {}).get("quantity", "")),
            "manifest": str(intent.get("compliance", {}).get("risk_manifest_version", "")),
            "receipt": json.dumps(receipt),
        }
        if self._redis is None:
            logger.info("[AUDIT] %s", json.dumps(entry))
            return
        # No maxlen cap: the audit trail must be durable, not silently trimmed.
        await self._redis.xadd(self.cfg.audit_stream, entry)
