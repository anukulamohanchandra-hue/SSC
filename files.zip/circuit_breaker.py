# ============================================================
# FILE: broker/circuit_breaker.py
# Counts consecutive API failures. At threshold it latches HALTED,
# which the execution engine checks before every order.
# ============================================================
import logging

logger = logging.getLogger("broker.circuit_breaker")


class SystemHaltException(Exception):
    """Raised when the circuit breaker has latched and orders are blocked."""


class OrderExecutionError(Exception):
    """Raised when an order fails after all retries (breaker not yet latched)."""


class CircuitBreaker:
    def __init__(self, threshold: int = 3):
        self.threshold = threshold
        self._failures = 0
        self._halted = False

    def record_failure(self) -> bool:
        """Returns True if this failure latched the breaker (HALT)."""
        self._failures += 1
        logger.warning("[CircuitBreaker] failure %d/%d", self._failures, self.threshold)
        if self._failures >= self.threshold:
            self._halted = True
            logger.critical("[CircuitBreaker] HALT latched after %d consecutive failures",
                            self._failures)
            return True
        return False

    def record_success(self) -> None:
        self._failures = 0

    @property
    def is_halted(self) -> bool:
        return self._halted

    def reset(self) -> None:
        """Operator-only. Clearing a latched breaker is a deliberate act."""
        self._failures = 0
        self._halted = False
        logger.info("[CircuitBreaker] reset by operator")
