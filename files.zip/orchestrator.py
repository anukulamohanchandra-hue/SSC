# ============================================================
# FILE: orchestrator.py
# Wires the components into a single runnable loop.
# Out of the box this runs in PAPER mode with the NullSignalEngine,
# so it is inert and safe: it will start, gate on market hours, and
# place nothing until you (a) implement a SignalEngine and
# (b) deliberately enable LIVE mode.
# ============================================================
import asyncio
import logging

from config import CONFIG, TradingMode
from market_calendar import MarketCalendar
from broker.circuit_breaker import CircuitBreaker, SystemHaltException
from broker.session_manager import AngelOneSession
from broker.execution_engine import ExecutionEngine
from risk.risk_manifest import RiskGovernor, HaltLevel
from signals.base import SignalEngine, NullSignalEngine

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(name)s %(message)s")
logger = logging.getLogger("orchestrator")

POLL_INTERVAL_S = 1.0


class Orchestrator:
    def __init__(self, signal_engine: SignalEngine | None = None):
        self.cfg = CONFIG
        self.cfg.assert_live_allowed()
        self.calendar = MarketCalendar(self.cfg.market_open, self.cfg.market_close,
                                       self.cfg.preopen_start, self.cfg.preopen_end)
        self.cb = CircuitBreaker(self.cfg.consecutive_api_failures_halt)
        self.governor = RiskGovernor(self.cfg)
        self.signal_engine = signal_engine or NullSignalEngine()

        self.session = AngelOneSession(self.cfg.api_key, self.cfg.client_id,
                                       self.cfg.password, self.cfg.totp_secret)
        self.execution = ExecutionEngine(self.cfg, self.session, self.cb)
        self._running = False

    async def _current_manifest(self):
        # Replace these inputs with live portfolio state. The win_rate /
        # avg_win / avg_loss MUST come from your backtest, not from thin air.
        return self.governor.build(
            nav=1_000_000.0, nav_open=1_000_000.0,
            realized_pnl=0.0, unrealized_pnl=0.0,
            win_rate=0.50, avg_win=1.0, avg_loss=1.0,  # neutral placeholder
            vix_current=14.0,
        )

    async def _handle_signal(self, signal_state: dict):
        manifest = await self._current_manifest()

        if manifest.halt_level is HaltLevel.HALT_L2:
            logger.critical("[Orchestrator] hard drawdown breach — flattening")
            await self.execution.emergency_flatten_all()
            self._running = False
            return

        intent = await self.signal_engine.generate_intent(signal_state, manifest)
        if intent is None:
            return  # HOLD — the safe default
        receipt = await self.execution.place_order(intent, manifest)
        logger.info("[Orchestrator] %s", receipt)

    async def run(self, signal_feed):
        """
        `signal_feed` is an async iterator yielding signal_state dicts
        (from your Redis signal_state hash / aggregator). In PAPER mode you
        can feed it recorded or synthetic ticks to validate behaviour.
        """
        self._running = True
        if self.cfg.trading_mode is TradingMode.LIVE:
            await self.session.ensure_valid()
        logger.info("[Orchestrator] running in %s mode", self.cfg.trading_mode.value)

        async for signal_state in signal_feed:
            if not self._running:
                break
            if self.cb.is_halted:
                logger.error("[Orchestrator] halted — idling")
                await asyncio.sleep(POLL_INTERVAL_S)
                continue
            if not self.calendar.is_open():
                await asyncio.sleep(POLL_INTERVAL_S)
                continue
            try:
                await self._handle_signal(signal_state)
            except SystemHaltException as e:
                logger.critical("[Orchestrator] SYSTEM HALT: %s", e)
                self._running = False


# ---- demo entrypoint: inert paper run --------------------------------------
async def _demo_feed():
    """Yields a couple of empty signal states then stops. Demonstrates that
    with the NullSignalEngine the system places nothing."""
    for _ in range(3):
        yield {}
        await asyncio.sleep(0.2)


async def main():
    orch = Orchestrator()  # PAPER + NullSignalEngine by default
    # Bypass the market-hours gate for the demo by forcing the loop body:
    manifest = await orch._current_manifest()
    logger.info("[demo] active manifest: %s", manifest)
    logger.info("[demo] mode=%s — NullSignalEngine places no orders",
                orch.cfg.trading_mode.value)


if __name__ == "__main__":
    asyncio.run(main())
