# ============================================================
# FILE: broker/rate_limiter.py
# Async token-bucket limiter. Enforces the SEBI / Angel One
# 10-orders-per-second ceiling that the original blueprint lacked.
# Used by EVERY path that can place/modify/cancel an order,
# including emergency_flatten (which could otherwise burst).
# ============================================================
import asyncio
import time


class AsyncTokenBucket:
    """
    Classic token bucket. `capacity` tokens, refilled at `rate` tokens/sec.
    acquire() blocks until a token is available, so callers can never
    exceed `rate` sustained operations per second.
    """

    def __init__(self, rate: float, capacity: float | None = None):
        if rate <= 0:
            raise ValueError("rate must be > 0")
        self.rate = rate
        self.capacity = capacity if capacity is not None else rate
        self._tokens = self.capacity
        self._last = time.monotonic()
        self._lock = asyncio.Lock()

    def _refill(self) -> None:
        now = time.monotonic()
        elapsed = now - self._last
        self._tokens = min(self.capacity, self._tokens + elapsed * self.rate)
        self._last = now

    async def acquire(self, tokens: float = 1.0) -> None:
        while True:
            async with self._lock:
                self._refill()
                if self._tokens >= tokens:
                    self._tokens -= tokens
                    return
                deficit = tokens - self._tokens
                wait_s = deficit / self.rate
            # Sleep outside the lock so other coroutines can refill-check.
            await asyncio.sleep(wait_s)

    @property
    def available(self) -> float:
        self._refill()
        return self._tokens
