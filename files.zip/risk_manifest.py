# ============================================================
# FILE: risk/risk_manifest.py
# Role 1 — Quant risk governance.
# Produces an immutable RiskManifest that authorises sizing,
# and evaluates the drawdown circuit breakers.
# ============================================================
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum

from config import Config


class HaltLevel(str, Enum):
    NONE = "NONE"
    ALERT_L1 = "SYSTEM_ALERT_LEVEL_1"   # soft: halve sizing, alert operator
    HALT_L2 = "SYSTEM_HALT_LEVEL_2"     # hard: cancel + flatten + halt


def full_kelly(win_rate: float, avg_win: float, avg_loss: float) -> float:
    """
    K = (b*p - q) / b ;  b = avg_win/avg_loss, p = win_rate, q = 1-p.
    NOTE: win_rate / avg_win / avg_loss are *estimates*. They are only
    meaningful once your signal engine has a backtested track record.
    Feeding guesses here produces confidently-wrong position sizes.
    """
    if avg_loss <= 0 or avg_win <= 0:
        return 0.0
    b = avg_win / avg_loss
    p = max(0.0, min(1.0, win_rate))
    q = 1.0 - p
    k = (b * p - q) / b
    return max(0.0, k)  # never size a negative-edge bet


@dataclass(frozen=True)
class RiskManifest:
    manifest_id: str
    generated_at: str
    nav: float
    kelly_fraction: float
    max_position_inr: float
    atr_multiplier: float
    drawdown_pct: float
    halt_level: HaltLevel
    sizing_scale: float  # 1.0 normal, 0.5 after soft breach, 0.0 when halted


class RiskGovernor:
    def __init__(self, cfg: Config):
        self.cfg = cfg

    def _fractional_kelly(self, k: float) -> float:
        return min(self.cfg.kelly_fraction_cap, k * self.cfg.kelly_base_multiplier)

    def evaluate_drawdown(self, realized: float, unrealized: float,
                          nav_open: float) -> tuple[HaltLevel, float]:
        if nav_open <= 0:
            return HaltLevel.HALT_L2, 0.0
        dd = (realized + unrealized) / nav_open
        if dd <= self.cfg.drawdown_hard_pct:
            return HaltLevel.HALT_L2, 0.0
        if dd <= self.cfg.drawdown_soft_pct:
            return HaltLevel.ALERT_L1, 0.5
        return HaltLevel.NONE, 1.0

    def build(self, *, nav: float, nav_open: float, realized_pnl: float,
              unrealized_pnl: float, win_rate: float, avg_win: float,
              avg_loss: float, vix_current: float) -> RiskManifest:
        halt, scale = self.evaluate_drawdown(realized_pnl, unrealized_pnl, nav_open)

        k = full_kelly(win_rate, avg_win, avg_loss)
        f_star = self._fractional_kelly(k) * scale

        atr_mult = (self.cfg.atr_multiplier_high_vix
                    if vix_current > self.cfg.high_vix_threshold
                    else self.cfg.atr_multiplier_default)

        # Position cap is the tighter of Kelly sizing and the hard 5%-NAV rule.
        max_pos = min(nav * f_star, nav * self.cfg.max_pct_nav_per_instrument)

        return RiskManifest(
            manifest_id=str(uuid.uuid4()),
            generated_at=datetime.now(timezone.utc).isoformat(),
            nav=nav,
            kelly_fraction=round(f_star, 4),
            max_position_inr=round(max_pos, 2),
            atr_multiplier=atr_mult,
            drawdown_pct=round((realized_pnl + unrealized_pnl) / nav_open, 4)
            if nav_open else 0.0,
            halt_level=halt,
            sizing_scale=scale,
        )

    @staticmethod
    def position_size(manifest: RiskManifest, entry_price: float) -> int:
        """Whole-unit position size implied by the manifest's INR cap."""
        if entry_price <= 0 or manifest.atr_multiplier <= 0:
            return 0
        denom = entry_price * manifest.atr_multiplier
        return max(0, int(manifest.max_position_inr // denom))
