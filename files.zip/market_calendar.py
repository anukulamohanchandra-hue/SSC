# ============================================================
# FILE: market_calendar.py
# Trading-hours gate. No signal is processed outside the window.
# Holiday list is intentionally minimal — wire it to the NSE
# holiday feed (refresh weekly) before relying on it in LIVE mode.
# ============================================================
from datetime import datetime, time
from zoneinfo import ZoneInfo

IST = ZoneInfo("Asia/Kolkata")

# Populate from the official NSE holiday list; refresh weekly.
NSE_HOLIDAYS: set[str] = set()  # e.g. {"2026-01-26", "2026-03-06"}


def _parse(hhmm: str) -> time:
    h, m = hhmm.split(":")
    return time(int(h), int(m))


class MarketCalendar:
    def __init__(self, open_str: str, close_str: str,
                 preopen_start: str, preopen_end: str):
        self.open = _parse(open_str)
        self.close = _parse(close_str)
        self.preopen_start = _parse(preopen_start)
        self.preopen_end = _parse(preopen_end)

    def now_ist(self) -> datetime:
        return datetime.now(IST)

    def is_holiday(self, dt: datetime | None = None) -> bool:
        dt = dt or self.now_ist()
        return dt.weekday() >= 5 or dt.strftime("%Y-%m-%d") in NSE_HOLIDAYS

    def is_open(self, dt: datetime | None = None) -> bool:
        dt = dt or self.now_ist()
        if self.is_holiday(dt):
            return False
        return self.open <= dt.time() <= self.close

    def in_preopen(self, dt: datetime | None = None) -> bool:
        dt = dt or self.now_ist()
        if self.is_holiday(dt):
            return False
        return self.preopen_start <= dt.time() <= self.preopen_end
