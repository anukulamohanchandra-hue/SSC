# ============================================================
# FILE: risk/order_validator.py
# Structural guardrail. Runs on every OrderIntent before it can
# reach the execution engine. Catches malformed / out-of-range
# output. NOTE: this validates *structure*, not *judgment* — a
# well-formed intent can still be a bad trade. That is what
# backtesting (not this validator) is for.
# ============================================================
from typing import Any

from risk.risk_manifest import RiskManifest

REQUIRED_PATHS = [
    "instrument.token",
    "instrument.symbol",
    "signal.action",
    "signal.quantity",
    "risk_params.stop_loss_price",
    "risk_params.risk_reward_ratio",
    "compliance.risk_manifest_version",
]

NUMERIC_RANGES = {
    "risk_params.risk_reward_ratio": (1.5, 20.0),
    "compliance.pct_of_nav": (0.001, 0.05),
    "routing_meta.news_sentiment_composite": (-1.0, 1.0),
}

VALID_ACTIONS = {"BUY", "SELL", "HOLD", "EMERGENCY_EXIT"}


def _get(d: dict, path: str) -> Any:
    cur: Any = d
    for part in path.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur[part]
    return cur


def validate_order_intent(intent: dict, manifest: RiskManifest) -> tuple[bool, str]:
    """Return (ok, reason). On failure the caller must HOLD and log."""
    if not isinstance(intent, dict):
        return False, "intent is not a dict"

    action = _get(intent, "signal.action")
    if action == "HOLD":
        return False, "action is HOLD — nothing to execute"
    if action not in VALID_ACTIONS:
        return False, f"invalid action: {action!r}"

    for path in REQUIRED_PATHS:
        if _get(intent, path) in (None, ""):
            return False, f"missing required field: {path}"

    for path, (lo, hi) in NUMERIC_RANGES.items():
        val = _get(intent, path)
        if val is None:
            continue  # presence already enforced for required paths
        try:
            v = float(val)
        except (TypeError, ValueError):
            return False, f"{path} is not numeric: {val!r}"
        if not (lo <= v <= hi):
            return False, f"{path}={v} outside [{lo}, {hi}]"

    qty = _get(intent, "signal.quantity")
    try:
        if int(qty) <= 0:
            return False, f"quantity must be positive, got {qty}"
    except (TypeError, ValueError):
        return False, f"quantity not an integer: {qty!r}"

    # Cross-check against the authorising manifest.
    if _get(intent, "compliance.risk_manifest_version") != manifest.manifest_id:
        return False, "risk_manifest_version does not match active manifest"
    pos_inr = _get(intent, "compliance.position_size_inr")
    if pos_inr is not None and float(pos_inr) > manifest.max_position_inr + 1e-6:
        return False, (f"position_size_inr {pos_inr} exceeds manifest cap "
                       f"{manifest.max_position_inr}")

    return True, "ok"
