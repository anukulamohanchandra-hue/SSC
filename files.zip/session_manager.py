# ============================================================
# FILE: broker/session_manager.py
# Angel One SmartAPI session lifecycle.
#
# Compliance notes (SEBI 2025 framework / Angel One SmartAPI):
#   - API sessions must log out automatically before each pre-open.
#     We force a fresh session per trading day rather than rolling a
#     ~24h JWT across days.
#   - Angel One moved auth toward OAuth. The SmartConnect SDK still
#     exposes generateSession(client, password, totp); that is the
#     concrete integration point used here. When you migrate to the
#     OAuth flow, replace _authenticate() only — the daily-reset and
#     pre-open-logout discipline around it stays the same.
# ============================================================
import asyncio
import logging
import time
from datetime import datetime, date
from typing import Optional
from zoneinfo import ZoneInfo

import pyotp
from SmartApi import SmartConnect

logger = logging.getLogger("broker.session")
IST = ZoneInfo("Asia/Kolkata")


class AngelOneSession:
    def __init__(self, api_key: str, client_id: str, password: str, totp_secret: str):
        self._api_key = api_key
        self._client_id = client_id
        self._password = password
        self._totp_secret = totp_secret

        self._smart: Optional[SmartConnect] = None
        self._jwt_token: Optional[str] = None
        self._feed_token: Optional[str] = None
        self._session_date: Optional[date] = None
        self._lock = asyncio.Lock()

    @property
    def smart(self) -> SmartConnect:
        if self._smart is None:
            raise RuntimeError("Session not initialised. Call ensure_valid() first.")
        return self._smart

    @property
    def feed_token(self) -> Optional[str]:
        return self._feed_token

    @property
    def jwt_token(self) -> Optional[str]:
        return self._jwt_token

    def _authenticate(self) -> None:
        """Blocking auth call. Replace body wholesale when moving to OAuth."""
        totp = pyotp.TOTP(self._totp_secret).now()
        self._smart = SmartConnect(api_key=self._api_key)
        data = self._smart.generateSession(self._client_id, self._password, totp)
        if not data or data.get("status") is False:
            raise ConnectionError(f"Angel One session creation failed: {data}")
        self._jwt_token = data["data"]["jwtToken"]
        self._feed_token = data["data"]["feedToken"]
        self._session_date = datetime.now(IST).date()
        logger.info("[Session] established for trading day %s", self._session_date)

    async def ensure_valid(self) -> None:
        """
        Guarantee a session valid for *today*. A session created on a prior
        day is treated as expired — this is the daily-reset requirement.
        """
        async with self._lock:
            today = datetime.now(IST).date()
            if self._smart is None or self._session_date != today:
                if self._session_date is not None and self._session_date != today:
                    logger.info("[Session] crossing trading day — forcing fresh login")
                # generateSession is blocking; run it off the event loop.
                await asyncio.to_thread(self._authenticate)

    async def logout(self) -> None:
        """Pre-open / end-of-day logout. Best-effort; always clears local state."""
        async with self._lock:
            try:
                if self._smart is not None:
                    await asyncio.to_thread(self._smart.terminateSession, self._client_id)
            except Exception as e:  # logout failures must never crash the system
                logger.warning("[Session] logout error (ignored): %s", e)
            finally:
                self._smart = None
                self._jwt_token = None
                self._feed_token = None
                self._session_date = None
                logger.info("[Session] cleared")
