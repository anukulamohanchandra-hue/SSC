# Autonomous Trading System — Compliance & Execution Core

This is the **infrastructure spine** of the blueprint, built for a single
own-account "tech-savvy retail" setup under SEBI's 2025 algo framework
(mandatory since 1 April 2026). It deliberately does **not** include a
strategy that decides trades — that is the one part only you can build and
validate (see `signals/base.py`).

## What's built

| File | Role |
|---|---|
| `config.py` | Central config. Holds the **PAPER-default** mode switch and the live-trading guard. |
| `broker/rate_limiter.py` | Token bucket enforcing the **10 OPS** ceiling the original blueprint lacked. |
| `broker/session_manager.py` | SmartAPI session with **forced daily reset** + pre-open logout. |
| `broker/execution_engine.py` | IP-bound, rate-limited, mode-aware order placement + durable audit. |
| `broker/circuit_breaker.py` | Consecutive-failure halt latch. |
| `risk/risk_manifest.py` | Kelly sizing (half-Kelly, 25% cap, 5%-NAV cap) + drawdown breakers. |
| `risk/order_validator.py` | Structural guardrail run before every order. |
| `signals/base.py` | **The strategy interface — a stub you must implement.** |
| `market_calendar.py` | NSE trading-hours gate. |
| `orchestrator.py` | Wires it together; runs inert in paper mode by default. |

## Why it ships in PAPER mode

`TRADING_MODE` defaults to `PAPER`. In paper mode **no order ever reaches
Angel One** — fills are simulated and logged. Going live requires setting
*two* environment variables on purpose:

```bash
export TRADING_MODE=LIVE
export LIVE_TRADING_CONFIRMED=true
```

If you set the first without the second, the system refuses to start. This
is intentional friction, not an obstacle to remove casually.

## The order you must do things in

1. **Implement `SignalEngine.generate_intent()`** with your actual logic.
2. **Backtest it** on out-of-sample data. The validator checks *structure*,
   never *profitability* — only backtesting can tell you if there's an edge.
   The Kelly inputs in `risk_manifest.py` are meaningless until you have a
   measured win-rate and win/loss ratio from this step.
3. **Forward paper-trade** it (LIVE-shaped data, PAPER execution) for a
   meaningful period.
4. Only then consider LIVE — and start on equity/delivery, not F&O.

## Compliance checklist before LIVE

- [ ] Static IP obtained and registered (SmartApi → My Profile → My APIs).
      Set `REGISTERED_STATIC_IP` and run the execution service from that IP.
- [ ] Host the execution service on a fixed-IP, India-based VM.
- [ ] One API key only (non-registered self-developed algos are limited to one).
- [ ] Daily session reset / pre-open logout active (handled by `session_manager`).
- [ ] Sustained order rate stays under 10 OPS (handled by `rate_limiter`).
- [ ] Audit trail persisted durably (Redis stream has no maxlen cap here).
- [ ] Plain-English description of your strategy logic kept on file.

> Self-use below 10 OPS does not require exchange algo registration or an RA
> licence. The moment anyone else trades on this, that exemption ends and the
> full provider/black-box regime applies. Confirm specifics with Angel One.

## Setup

```bash
pip install pyotp smartapi-python redis
# credentials via environment, never in code:
export ANGEL_API_KEY=... ANGEL_CLIENT_ID=... ANGEL_PASSWORD=... ANGEL_TOTP_SECRET=...
python orchestrator.py   # inert paper demo
```

Compliance details here reflect the framework as of early 2026; verify the
current SmartAPI and NSE operational requirements before going live. This
code is infrastructure, not financial advice.
